//permet d'ajouter un nouvel élément à la liste de taches
function addNewElement() {
}

//permet de supprimer tous les éléments de la liste
function removeEveryElement(){
}

//permet de rechercher un ou des éléments de la liste
function searchAnElement(){
}

// Detecter la pression sur enter sur le bouton add
var input = document.getElementById("newEntry");

input.addEventListener("keyup", function(event) {
});